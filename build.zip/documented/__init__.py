from documented.documented import Documented
from documented.error import DocumentedError
